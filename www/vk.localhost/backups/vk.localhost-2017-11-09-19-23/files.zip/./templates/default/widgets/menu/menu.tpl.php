<?php

    $this->menu($widget->options['menu'], $widget->options['is_detect'], 'menu', $widget->options['max_items'], true, (!empty($widget->options['template']) ? $widget->options['template'] : 'menu'), $widget->title);
