<?php echo html_input('hidden', $field->element_name, $value, array('id'=>$field->id)); ?>
