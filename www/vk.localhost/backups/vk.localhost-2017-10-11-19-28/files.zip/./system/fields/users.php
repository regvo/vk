<?php

class fieldUsers extends cmsFormField {

    public $title = LANG_PARSER_USERS;
    public $is_public = false;
	public $allow_index = false;

}
