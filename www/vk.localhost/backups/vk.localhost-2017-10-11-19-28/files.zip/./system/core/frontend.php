<?php
class cmsFrontend extends cmsController {}
