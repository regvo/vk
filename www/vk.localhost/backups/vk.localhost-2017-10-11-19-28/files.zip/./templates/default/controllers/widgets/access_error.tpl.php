<div class="access_denied_wrap access_denied_<?php echo $denied_type; ?>">

    <div class="access_image">403</div>

    <div class="access_text">

        <h1><?php echo LANG_ACCESS_DENIED; ?></h1>
        <p><?php echo $hint; ?></p>

    </div>

</div>