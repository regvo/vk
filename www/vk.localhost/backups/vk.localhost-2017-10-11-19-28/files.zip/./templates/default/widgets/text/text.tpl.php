<div class="widget_text_block"><?php echo $widget->options['content']; ?></div>

