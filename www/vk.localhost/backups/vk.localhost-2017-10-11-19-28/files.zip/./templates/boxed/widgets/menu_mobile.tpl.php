<a href="javascript:void(0);" class="menu_mobile is_mm" style="display:none">
	<i class="bx-bars"></i> &nbsp; <?php html($widget['title']); ?>
</a>
<nav id="menu_mobile" style="display:none">
	<?php echo $widget['body']; ?>
</nav>