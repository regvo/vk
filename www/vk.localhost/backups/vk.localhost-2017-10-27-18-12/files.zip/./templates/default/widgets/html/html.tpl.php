<div class="widget_html_block"><?php echo $widget->options['content']; ?></div>

