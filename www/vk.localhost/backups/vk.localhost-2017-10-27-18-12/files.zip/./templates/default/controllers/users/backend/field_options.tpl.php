<?php
$this->renderControllerChild('admin', 'ctypes_field_options', array(
    'is_can_in_filter' => $is_can_in_filter,
    'options'          => $options,
    'values'           => $values
));