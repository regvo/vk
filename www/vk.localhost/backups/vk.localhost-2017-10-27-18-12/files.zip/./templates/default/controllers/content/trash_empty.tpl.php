<?php
    $this->setPageTitle(LANG_BASKET_TITLE);
    $this->addBreadcrumb(LANG_BASKET_TITLE);
?>

<h1><?php echo LANG_BASKET_TITLE; ?></h1>


<div id="trash_content_empty_list"><?php echo LANG_NO_ITEMS; ?></div>
