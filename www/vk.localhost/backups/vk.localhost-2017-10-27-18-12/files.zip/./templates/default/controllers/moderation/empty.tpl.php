<?php
    $this->setPageTitle(LANG_MODERATION);
    $this->addBreadcrumb(LANG_MODERATION);
?>

<h1><?php echo LANG_MODERATION; ?></h1>

<div id="moderation_content_list">
    <p><?php echo LANG_MODERATION_NO_TASKS; ?></p>
</div>
