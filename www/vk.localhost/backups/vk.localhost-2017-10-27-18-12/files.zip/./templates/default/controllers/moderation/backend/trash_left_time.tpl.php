<div class="width_320">
<?php
    $this->renderForm($form, $mod, array(
        'action' => href_to('admin', 'controllers', array('edit', 'moderation', 'edit_trash_left_time', $mod['id'])),
        'method' => 'ajax'
    ), $errors); ?>
</div>
<script type="text/javascript">
    function leftTimeSuccess (form_data, result){
        if(result.trash_left_time){
            $('#moderator-1 .trash_left_time_num').html(result.trash_left_time);
        }
        icms.modal.close();
    }
</script>